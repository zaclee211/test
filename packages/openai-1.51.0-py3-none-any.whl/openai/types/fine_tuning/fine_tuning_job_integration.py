# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


from .fine_tuning_job_wandb_integration_object import FineTuningJobWandbIntegrationObject

FineTuningJobIntegration = FineTuningJobWandbIntegrationObject
